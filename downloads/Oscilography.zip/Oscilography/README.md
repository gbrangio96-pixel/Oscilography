# Oscilography

Aplicação em português para análise dos canais digitais de oscilografias COMTRADE. Extrai automaticamente as identificações do CFG e informa transições 0 → 1, retornos 1 → 0 e canais já ativos no início. Exporta o resultado em JSON e relatório automático PDF. Inclui classificação rastreável por perfis e validação de integridade dos arquivos.

## Executar

Requer Python 3.10 ou superior, sem dependências externas. Extraia o ZIP e abra um terminal na pasta `Oscilography`.

```sh
python3 server.py --port 8000
```

Abra `http://localhost:8000` no navegador e selecione os arquivos CFG e DAT do mesmo registro, ou um arquivo único CFF/ZIP. No Windows, use `py server.py --port 8000` se o comando `python3` não estiver disponível. Encerre com Ctrl+C. Limite total: 32 MB por par. Os arquivos são processados em memória e não são salvos pelo aplicativo.

## Validar

```sh
python3 -m unittest discover -s tests -v
node --test tests/test_*.js
```

Suporta canais digitais em DAT ASCII, BINARY, BINARY32 e FLOAT32, com configuração COMTRADE 1991/1999/2001/2013. Os canais analógicos são lidos com escala a × amostra + b e unidades do CFG; há estatísticas e gráficos. Tempos são relativos à referência do DAT, com multiplicador do CFG e reconstrução pelas taxas de amostragem quando o timestamp é zero. Identificação de função usa o nome original, sem inferir códigos ANSI ou traduzir identificações proprietárias.

## Formatos e revisões

A revisão **2001** é reconhecida junto com 1991, 1999 e 2013. Além do par CFG/DAT, é possível carregar CFF, ZIP com um registro e DAT dividido em segmentos numerados. Campos de revisão não padronizados são diagnosticados e lidos em modo de compatibilidade somente quando a estrutura passa pelas validações.

Veja [COMPATIBILITY.md](COMPATIBILITY.md) para formatos binários, codificações, limites e variações de exportadores. O suporte validado não equivale a uma garantia para qualquer arquivo proprietário ou danificado.

## Comparar duas oscilografias

Selecione **Comparar dois registros** e carregue os pares CFG/DAT de A e B. A tabela destaca os canais ativados em ambos, somente em A ou somente em B, além dos canais ausentes no CFG e das correspondências ambíguas. Os horários, os retornos e a quantidade de ativações não influenciam a classificação. Os sinais já ativos na primeira amostra são indicados separadamente e não contam como nova ativação.

A associação usa nome/fase originais ou equivalências explícitas confirmadas nos perfis de interpretação. Identificações repetidas, aliases em conflito e regras conflitantes são apresentados como ambíguos. Horários não influenciam a comparação. Ativações respeitam a polaridade configurada no perfil, incluindo sinais ativos em 0.

## HDR opcional e objeto relacionado

Você pode enviar um `.hdr` separado para cada registro. Quando houver seção HDR no CFF ou um HDR de mesmo nome-base/pasta no ZIP, a leitura é automática. Sem HDR, a análise segue normalmente.

A aplicação procura o nome do objeto protegido (LT, transformador, banco de capacitores/reatores etc.) em campos explícitos como “ObjectID”, “Objeto protegido” e “Protected object”. Menções em texto livre são sugestões. Múltiplos candidatos ficam ambíguos, sem selecionar arbitrariamente. O nome original e a linha de evidência são preservados; a classificação do tipo depende do texto disponível, sem inferir tensões, potência ou identificação ausentes.

O objeto aparece na interface, no resumo do PDF e na rastreabilidade, com nome/hash do HDR. É possível revisar manualmente a identificação na interface, informando responsável e justificativa; a extração original permanece no JSON. O texto do HDR não altera as funções de proteção nem as polaridades dos canais. O upload separado de HDR tem limite de 2 MB.

## Perfis e classificação das binárias

Abra **Perfis de interpretação** para importar, exportar, editar ou salvar perfis no navegador. Há um perfil independente para A e para B. O botão **Revisar classificação** preenche automaticamente o nome/fase do canal a partir do CFG; você só revisa o significado e a polaridade. Perfis específicos têm precedência sobre as sugestões genéricas. Nomes desconhecidos permanecem não classificados.

Categorias: partida, disparo, bloqueio, alarme, posição e desconhecido. Função ANSI é opcional. A interface mostra origem da classificação, regra, perfil/versão, justificativa, responsável e estado ativo. Regras confirmadas ou revisões manuais exigem responsável e justificativa. Nenhum fabricante ou firmware é presumido automaticamente.

Veja [PROFILES.md](PROFILES.md) para o esquema JSON, escopo por estação/equipamento, prioridades, curingas, equivalências entre fabricantes e critérios de validação. O perfil genérico pode ser baixado na interface. Ele é conservador e suas classificações são sugestões, sem equivalências automáticas.

## Qualidade e relatório PDF

Erros estruturais bloqueiam a análise: contagem de canais incompatível, DAT truncado, amostras fora de ordem, estados digitais inválidos, datas inválidas e limites de amostras inconsistentes. Lacunas de amostras, identificações duplicadas, timestamps reconstruídos/repetidos e conflitos de regras geram alertas visíveis. A validação é estrutural e não comprova que dois arquivos compatíveis são da mesma ocorrência.

Após analisar ou comparar, clique em **Baixar relatório PDF**. O documento é gerado no navegador sem bibliotecas adicionais ou serviços externos. Contém resumo executivo, evidências, conclusão automática, qualidade, hashes SHA-256 dos arquivos e do perfil, regras aplicadas, responsável e anexo com todos os canais. Sugestões e fatos observados são identificados separadamente; a conclusão não afirma a causa da falta ou a abertura efetiva do disjuntor apenas por uma binária.

O relatório usa todos os canais, independentemente dos filtros. Caracteres fora do alfabeto ocidental aparecem como códigos U+XXXX; as identificações originais permanecem no JSON. Preserve CFG/DAT originais, perfil JSON e análise JSON para revisão reproduzível.

O PDF tem formato A4, capa com resumo executivo, cartões de indicadores, tabelas com cabeçalhos repetidos, distinção visual entre sugestões e classificações confirmadas, anexo técnico, numeração de páginas e marcadores de navegação por seção. Textos longos e tabelas são paginados automaticamente, sem cortar identificações ou justificativas. Os horários continuam fora da comparação de atuações.

Veja [o relatório de demonstração](examples/relatorio-demonstracao.pdf), produzido com dados sintéticos e identificado como exemplo. O PDF é gerado localmente no navegador, sem bibliotecas a instalar. Para regenerar a demonstração no desenvolvimento: `node examples/gerar-demonstracao.js`.

Node.js é necessário apenas para executar os testes da comparação; o aplicativo continua usando somente Python e um navegador.

O estado ativo é definido pela regra (0 ou 1). Sem regra, estado 1 é uma hipótese explícita. O campo de estado normal do CFG é exibido, mas não define automaticamente a polaridade. Uma transição digital não comprova disparo de proteção: contatos, alarmes e sinais de lógica também podem estar registrados. Operações anteriores à primeira amostra e pulsos entre amostras não podem ser determinados. A validação usa registros sintéticos; valide também com registros reais dos relés utilizados antes de uso operacional.

## Gerar o pacote distribuível

```sh
python3 package_app.py
```

O arquivo `downloads/Oscilography.zip` inclui aplicação, documentação e testes, sem dependências externas para executar a aplicação.

## Tempo ativo e valores analógicos

Cada canal digital apresenta intervalos ativos e o tempo total observado, conforme a polaridade do perfil. Intervalos já ativos no início ou ainda ativos no fim são marcados como incompletos. O cálculo cobre da primeira à última amostra: não extrapola além do registro. Lacunas de amostras tornam a duração estimada; tempos de transição continuam limitados à resolução de amostragem. A comparação permanece em duas colunas, sem calcular diferenças de horários entre A e B.

Os canais analógicos apresentam nome, fase, unidade, referência P/S, mínimo, máximo, pico absoluto, média e RMS global amostral da janela. O RMS inclui componente contínua, não é RMS de ciclo, fasor ou média ponderada pelo tempo. Amostras ausentes são excluídas das estatísticas e sinalizadas. A relação primário/secundário é informada, sem conversão automática de TC/TP. Não há diagnóstico automático de tipo de falta.

Na tela, selecione o canal para visualizar a curva de cada registro. Gráficos aplicam o skew do CFG, usam envelope min/max quando necessário e não interpolam lacunas. O PDF contém estatísticas de todos os canais e gráficos dos primeiros oito por registro; os demais continuam disponíveis na interface. Estatísticas são calculadas com todas as amostras válidas, independentemente da redução visual.

Para identificar fases, envie CFG + DAT: o campo de fase do CFG é preservado; quando vazio, a fase fica não informada. Para o objeto protegido, acrescente o HDR opcional; `ObjectID` é tratado como identificação explícita, sem inventar nome ou tipo ausente no texto.

## Catálogo ANSI e sequência de ativações

A seção **Catálogo ANSI** permite pesquisar códigos, nomes e descrições de funções usuais de proteção. O botão **Usar código** preenche a função na regra personalizada; o catálogo também aparece como sugestão no campo Função ANSI. Ele é uma referência de uso comum, não uma reprodução completa da norma ou da nomenclatura de cada fabricante.

Depois da leitura, **Funções ANSI associadas e sequência de ativações** apresenta os códigos e nomes vinculados aos sinais, suas ativações, a origem da associação e os canais originais. Cada registro tem sua sequência, com ordem e instante em segundos do DAT. Eventos com o mesmo timestamp compartilham a ordem: não se inventa precedência entre eventos simultâneos. O filtro de funções mapeadas mantém a ordem global original, mesmo quando oculta eventos sem associação.

Sinais já ativos na primeira amostra ficam separados, sem gerar uma ativação artificial em t=0. A comparação e o PDF mantêm A e B em duas colunas, com sequências independentes; não há sincronização de relógios nem delta temporal entre os arquivos.

A função é atribuída pela regra do perfil. Regras genéricas conservadoras podem sugerir associações a partir de identificadores explícitos; sugestões não equivalem a confirmação. O campo aceita códigos ou um nome exato do catálogo, assim como expressões de múltiplos códigos (por exemplo, `50/51`). Códigos fora da referência permanecem identificados como personalizados. Um único sinal associado a vários códigos não comprova a atuação individual de cada função. A lista descreve funções associadas a sinais ativados, sem identificar automaticamente a responsável pelo trip.

Os dados exportados em JSON incluem `ansi.functions`, `ansi.timeline`, `ansi.initial_active` e `ansi.unmapped_channels`, junto da versão do catálogo. O relatório PDF inclui as mesmas evidências independentemente dos filtros selecionados na tela.

### Correções de revisão

A revisão corrigiu a leitura de campos antigos do objeto ao alternar entre análise individual e comparação, a exibição de pontos analógicos isolados e a preservação de extremos na redução dos gráficos próximos de lacunas. O RMS usa acumulação escalada para evitar overflow intermediário. O valor ASCII `99999` é preservado na revisão 1991 e tratado como marcador de ausência nas revisões posteriores. Instantes ANSI usam precisão adicional quando necessário, para não apresentar eventos distintos de nanossegundos como se fossem iguais. Equivalências confirmadas usam códigos ANSI normalizados mesmo quando um perfil declara o nome da função e o outro seu código.
